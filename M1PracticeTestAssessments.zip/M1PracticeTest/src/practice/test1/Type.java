package practice.test1;

public enum Type{
	VEG,
	NON_VEG;
}