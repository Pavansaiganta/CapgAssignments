package practice.test.exception;

public class InvalidFoodDetailsException extends Exception {

 public InvalidFoodDetailsException(String string) {
		// TODO Auto-generated constructor stub
	}
}
