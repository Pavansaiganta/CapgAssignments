package practice.test.exception;

public class InvalidFoodRegionException  extends InvalidFoodDetailsException{

	public InvalidFoodRegionException(String s) {
		super(s);
	}
	
}


